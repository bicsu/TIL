# CRUD + 챗봇

- Model
  - todo
    - title
    - content
    - deadline
- URL
  - /
  - /todos/create
  - /todos/edit
  - /todos/update
  - /todos/delete
- chatbot
  - "긴급" : deadline이 가장 가까운 todo 응답
  - "투두" : 해야 할 일 목록 인덱스 페이지 링크 버튼 전송
- 