# CBV

- 프로젝트 이름 : CBV
- 앱 이름 : posts
- `settings.py` 수정
- https://your-server-url/posts/ => index페이지



- 프로젝트 이름 : CBV_CRUD
- 앱 이름 : questions
- 모델 설정 
  - title 
  - answerA
  - answerB
- CBV 구조로 CRUD 로직 완성
  - `from django.views.generic import ??????`
  - `''` => `ListView`
  - `detail/`  => `DetailView`
  - `create/` => `CreateView`
  - `update/` => `UpdateView`
  - `delete/` => `DeleteView`





